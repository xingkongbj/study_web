An open JavaScript tutorial book, focusing on client devices, written in Chinese.
